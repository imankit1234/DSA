class Hero {
    public:
    int health;
    char level;
};