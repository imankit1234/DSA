# first program

print("Namaste Dunia")
