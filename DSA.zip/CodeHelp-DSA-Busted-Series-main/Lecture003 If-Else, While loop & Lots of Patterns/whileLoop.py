n=int(input())
i=1
while i<=n:
  print(i,end=" ")
  i=i+1
  
